#!/bin/sh
clear
echo "-----------------------------------------------------"
echo " Pulse <ENTER> cuando desee desbloquear el SEMÁFORO "
echo "-----------------------------------------------------"
./a.out t
echo "------------------< FIN de toma-sem.sh >-------------"
