#!/bin/sh
clear
echo "-----------------------------------------------------"
echo " Crea un Conjunto de un único Semáforo IPC System V "
echo "-----------------------------------------------------"
./a.out c
echo "------------------< FIN de crea-sem.sh >-------------"
